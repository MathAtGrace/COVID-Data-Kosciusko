# COVID-Data-Kosciusko
A small webpage that will keep up-to-date data on COVID19 in and around Kosciusko County
